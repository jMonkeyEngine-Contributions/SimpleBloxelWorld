/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.respublic.BlockManagement;

import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;

/**
 *
 * @author MichealZuegg
 */
public abstract class Block {
    public enum Neightbour{
        Top,Bottom,Front,Back,Left,Right;
    }
    public enum Face{
        Top,Bottom,Front,Back,Left,Right;
    }
    
    public abstract Vector3f[]  getNormals(Face face,Block[] neightbours);
    public abstract Vector2f[]  getTexCoord(Face face,Block[] neightbours);
}
