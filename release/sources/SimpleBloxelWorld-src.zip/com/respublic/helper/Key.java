/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.respublic.helper;

/**
 *
 * @author MichealZuegg
 */
public class Key {

    public static String IndexToKey(int x, int y, int z) {
        return x + ":" + y + ":" + z;
    }

    public static int[] KeyToIndex(String key) {
        int index[] = new int[3];
        int pos1 = key.indexOf(":");
        int pos2 = key.lastIndexOf(":");
        index[0] = Integer.parseInt(key.substring(0, pos1));
        index[1] = Integer.parseInt(key.substring(pos1 + 1, pos2));
        index[2] = Integer.parseInt(key.substring(pos2 + 1, key.length()));
        return index;
    }
}
