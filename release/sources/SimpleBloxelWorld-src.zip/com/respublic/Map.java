/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.respublic;

import com.jme3.app.state.AbstractAppState;

/**
 *
 * @author MichealZuegg
 */
public class Map extends AbstractAppState{

    
}
