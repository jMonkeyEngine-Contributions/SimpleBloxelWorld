/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.respublic;

import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.Node;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.util.BufferUtils;
import com.respublic.helper.Key;
import com.respublic.helper.MeshData;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author MichealZuegg
 */
public class BlockManager {

    int tileSizeX, tileSizeY, tileSizeZ;
    ConcurrentHashMap<String, BlockTile> blockTiles;
    float scale;
    public BlockManager(int tileSizeX, int tileSizeY, int tileSizeZ,float scale) {
        this.tileSizeX = tileSizeX;
        this.tileSizeY = tileSizeY;
        this.tileSizeZ = tileSizeZ;
        this.blockTiles = new ConcurrentHashMap<String, BlockTile>();
        this.scale=scale;
    }

    public String addBlock(Class b, int x, int y, int z) {
        int tileX = x / tileSizeX;
        int tileY = y / tileSizeY;
        int tileZ = z / tileSizeZ;
        BlockTile tile = this.getBlockTile(tileX, tileY, tileZ);
        if (tile == null) {
            tile = new BlockTile(Key.IndexToKey(tileX, tileY, tileZ), this);
            this.setBlockTile(tile);
        }
        tile.addBlock(b, x, y, z);
        return tile.getKey();
    }

    public String removeBlock(int x, int y, int z){
        int tileX = x / tileSizeX;
        int tileY = y / tileSizeY;
        int tileZ = z / tileSizeZ;
        BlockTile tile = this.getBlockTile(tileX, tileY, tileZ);
        if (tile != null) {
            tile.removeBlock(x, y, z);
            return tile.getKey();
        }
        return null;
    }
    
    public Class getBlock(int x, int y, int z) {
        int tileX = x / tileSizeX;
        int tileY = y / tileSizeY;
        int tileZ = z / tileSizeZ;
        BlockTile tile = this.getBlockTile(tileX, tileY, tileZ);
        if (tile == null) {
            return null;
        } else {
            return tile.getBlock(x, y, z);
        }
    }

    public BlockTile getBlockTile(int x, int y, int z) {
        return this.blockTiles.get(Key.IndexToKey(x, y, z));
    }

    public String setBlockTile(BlockTile tile) {
        this.blockTiles.put(tile.getKey(), tile);
        return tile.getKey();
    }

    public Set<String> getBlockTiles() {
        return this.blockTiles.keySet();
    }

    public Node getDebugMeshFromTile(String key, Class blockType) {
        Node tileNode = new Node("Tile Index:" + key + ",Type:" + blockType.getName());
        BlockTile tile = this.blockTiles.get(key);

        if (tile != null) {
            MeshData data=new MeshData();
            tile.getMesh(blockType, scale, data);
            IntBuffer indexBuffer = BufferUtils.createIntBuffer(data.getVertices().size());
            FloatBuffer vertexBuffer = BufferUtils.createFloatBuffer(data.getVertices().size() * 3);
            FloatBuffer normalBuffer = BufferUtils.createFloatBuffer(data.getVertices().size() * 3);
            FloatBuffer texCoord1Buffer = BufferUtils.createFloatBuffer(data.getVertices().size() * 2);
            int count = 0;
            for (Vector3f c : data.getVertices()) {
                indexBuffer.put(count);
                vertexBuffer.put(c.x);
                vertexBuffer.put(c.y);
                vertexBuffer.put(c.z);
                count++;
            }
            for(Vector3f c: data.getNormals()){
                normalBuffer.put(c.x);
                normalBuffer.put(c.y);
                normalBuffer.put(c.z);
            }
            for(Vector2f c: data.getTexCoord()){
                texCoord1Buffer.put(c.x);
                texCoord1Buffer.put(c.y);
            }
            Mesh m=new Mesh();
            indexBuffer.flip();
            vertexBuffer.flip();
            normalBuffer.flip();
            texCoord1Buffer.flip();
            m.setBuffer(Type.Index, 1, indexBuffer);
            m.setBuffer(Type.Position, 3, vertexBuffer);
            m.setBuffer(Type.Normal, 3, normalBuffer);
            m.setBuffer(Type.TexCoord, 2, texCoord1Buffer);
            m.updateCounts();
            m.updateBound();
            m.setMode(Mesh.Mode.Triangles);
            
            Geometry geometry=new Geometry(tileNode.getName()+",Geometry",m);
            tileNode.attachChild(geometry);
        }
        return tileNode;
    }
}
