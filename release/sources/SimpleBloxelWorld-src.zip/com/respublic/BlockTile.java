/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.respublic;

import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.respublic.helper.Key;
import com.respublic.helper.MeshData;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author MichealZuegg
 */
public class BlockTile {

    int keyX, keyY, keyZ;
    String key;
    ConcurrentHashMap<String, Class> blocks;
    BlockManager blockManager;

    public BlockTile(String key, BlockManager blockManager) {
        this.key = key;
        int[] keys = Key.KeyToIndex(key);
        keyX = keys[0];
        keyY = keys[1];
        keyZ = keys[2];
        blocks = new ConcurrentHashMap<String, Class>();
        this.blockManager = blockManager;
    }

    public void addBlock(Class b, int x, int y, int z) {
        this.blocks.put(Key.IndexToKey(x, y, z), b);
    }
    
    public void removeBlock(int x, int y, int z){
        this.blocks.remove(Key.IndexToKey(x, y, z));
    }

    public Class getBlock(int x, int y, int z) {
        return this.blocks.get(Key.IndexToKey(x, y, z));
    }

    public String getKey() {
        return key;
    }

    public int getKeyX() {
        return keyX;
    }

    public int getKeyY() {
        return keyY;
    }

    public int getKeyZ() {
        return keyZ;
    }

    public void getMesh(Class blockType, float scale, MeshData data) {
        for (String s : this.blocks.keySet()) {
            Class block = this.blocks.get(s);
            Vector2f t10=new Vector2f(1,0);
            Vector2f t11=new Vector2f(1,1);
            Vector2f t01=new Vector2f(0,1);
            Vector2f t00=new Vector2f(0,0);
            if (block != null) {
                //System.out.println("C1");
                if (block == blockType) {
                    //System.out.println("C2");
                    //Upper bounds
                    int[] KeyToIndex = Key.KeyToIndex(s);
                    Class blockToCheck = this.blockManager.getBlock(KeyToIndex[0], KeyToIndex[1] + 1, KeyToIndex[2]);
                    Vector3f center = new Vector3f(KeyToIndex[0] * scale, KeyToIndex[1] * scale, KeyToIndex[2] * scale);
                    if (blockToCheck==null || blockToCheck != blockType) {
                        //System.out.println("C3");
                        Vector3f normal=new Vector3f(0,1,0);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        
                        float scaleHalf = scale / 2;
                        Vector3f p1 = center.add(new Vector3f(-scaleHalf, scaleHalf, -scaleHalf));
                        Vector3f p2 = center.add(new Vector3f(-scaleHalf, scaleHalf, +scaleHalf));
                        Vector3f p3 = center.add(new Vector3f(scaleHalf, scaleHalf, +scaleHalf));
                        Vector3f p4 = center.add(new Vector3f(scaleHalf, scaleHalf, -scaleHalf));
                        data.addVertex(p1);
                        data.addVertex(p2);
                        data.addVertex(p3);
                        data.addTexCoord(t00);
                        data.addTexCoord(t01);
                        data.addTexCoord(t11);
                        data.addVertex(p1);
                        data.addVertex(p3);
                        data.addVertex(p4);
                        data.addTexCoord(t00);
                        data.addTexCoord(t11);
                        data.addTexCoord(t10);
                    }


                    //Lower bounds
                    blockToCheck = this.blockManager.getBlock(KeyToIndex[0], KeyToIndex[1] - 1, KeyToIndex[2]);

                    if (blockToCheck==null || blockToCheck != blockType) {
                        Vector3f normal=new Vector3f(0,-1,0);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        float scaleHalf = scale / 2;
                        Vector3f p4 = center.add(new Vector3f(-scaleHalf, -scaleHalf, -scaleHalf));
                        Vector3f p3 = center.add(new Vector3f(-scaleHalf, -scaleHalf, +scaleHalf));
                        Vector3f p2 = center.add(new Vector3f(scaleHalf, -scaleHalf, +scaleHalf));
                        Vector3f p1 = center.add(new Vector3f(scaleHalf, -scaleHalf, -scaleHalf));
                        data.addVertex(p1);
                        data.addVertex(p2);
                        data.addVertex(p3);
                        data.addTexCoord(t00);
                        data.addTexCoord(t01);
                        data.addTexCoord(t11);
                        data.addVertex(p1);
                        data.addVertex(p3);
                        data.addVertex(p4);
                        data.addTexCoord(t00);
                        data.addTexCoord(t11);
                        data.addTexCoord(t10);
                    }

                    //Front bounds
                    blockToCheck = this.blockManager.getBlock(KeyToIndex[0], KeyToIndex[1] , KeyToIndex[2]-1);

                    if (blockToCheck==null || blockToCheck != blockType) {
                        Vector3f normal=new Vector3f(0,0,-1);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        float scaleHalf = scale / 2;
                        Vector3f p1 = center.add(new Vector3f(-scaleHalf, -scaleHalf, -scaleHalf));
                        Vector3f p2 = center.add(new Vector3f(-scaleHalf, scaleHalf, -scaleHalf));
                        Vector3f p3 = center.add(new Vector3f(scaleHalf, scaleHalf, -scaleHalf));
                        Vector3f p4 = center.add(new Vector3f(+scaleHalf, -scaleHalf, -scaleHalf));
                        data.addVertex(p1);
                        data.addVertex(p2);
                        data.addVertex(p3);
                        data.addTexCoord(t00);
                        data.addTexCoord(t01);
                        data.addTexCoord(t11);
                        data.addVertex(p1);
                        data.addVertex(p3);
                        data.addVertex(p4);
                        data.addTexCoord(t00);
                        data.addTexCoord(t11);
                        data.addTexCoord(t10);
                    }

                    //Back bounds
                    blockToCheck = this.blockManager.getBlock(KeyToIndex[0], KeyToIndex[1], KeyToIndex[2]+1);

                    if (blockToCheck==null || blockToCheck != blockType) {
                        Vector3f normal=new Vector3f(0,0,1);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        float scaleHalf = scale / 2;
                        Vector3f p4 = center.add(new Vector3f(-scaleHalf, -scaleHalf, scaleHalf));
                        Vector3f p3 = center.add(new Vector3f(-scaleHalf, scaleHalf, scaleHalf));
                        Vector3f p2 = center.add(new Vector3f(scaleHalf,  -scaleHalf, scaleHalf));
                        Vector3f p1 = center.add(new Vector3f(+scaleHalf, scaleHalf, scaleHalf));
                        
                        data.addVertex(p4);
                        data.addVertex(p2);
                        data.addVertex(p1);
                        data.addTexCoord(t10);
                        data.addTexCoord(t01);
                        data.addTexCoord(t00);
                        data.addVertex(p1);
                        data.addVertex(p3);
                        data.addVertex(p4);
                        data.addTexCoord(t00);
                        data.addTexCoord(t11);
                        data.addTexCoord(t10);
                    }

                    //Left bounds
                    blockToCheck = this.blockManager.getBlock(KeyToIndex[0]-1, KeyToIndex[1], KeyToIndex[2]);

                    if (blockToCheck==null || blockToCheck != blockType) {
                        Vector3f normal=new Vector3f(-1,0,0);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        float scaleHalf = scale / 2;
                        Vector3f p4 = center.add(new Vector3f(-scaleHalf, -scaleHalf, -scaleHalf));
                        Vector3f p3 = center.add(new Vector3f(-scaleHalf, -scaleHalf, scaleHalf));
                        Vector3f p2 = center.add(new Vector3f(-scaleHalf, scaleHalf, scaleHalf));
                        Vector3f p1 = center.add(new Vector3f(-scaleHalf, scaleHalf, -scaleHalf));
                        data.addVertex(p1);
                        data.addVertex(p3);
                        data.addVertex(p2);
                        data.addTexCoord(t00);
                        data.addTexCoord(t11);
                        data.addTexCoord(t01);
                        data.addVertex(p1);
                        data.addVertex(p4);
                        data.addVertex(p3);
                        data.addTexCoord(t00);
                        data.addTexCoord(t10);
                        data.addTexCoord(t11);
                    }

                    //Right bounds
                    blockToCheck = this.blockManager.getBlock(KeyToIndex[0]+1, KeyToIndex[1], KeyToIndex[2]);

                    if (blockToCheck==null || blockToCheck != blockType) {

                        Vector3f normal=new Vector3f(1,0,0);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        data.addNormal(normal);
                        
                        float scaleHalf = scale / 2;
                        Vector3f p4 = center.add(new Vector3f(scaleHalf, -scaleHalf, -scaleHalf));
                        Vector3f p3 = center.add(new Vector3f(scaleHalf, -scaleHalf, scaleHalf));
                        Vector3f p2 = center.add(new Vector3f(scaleHalf, scaleHalf, scaleHalf));
                        Vector3f p1 = center.add(new Vector3f(scaleHalf, scaleHalf, -scaleHalf));
                        data.addVertex(p1);
                        data.addVertex(p2);
                        data.addVertex(p3);
                        data.addTexCoord(t00);
                        data.addTexCoord(t01);
                        data.addTexCoord(t11);
                        data.addVertex(p1);
                        data.addVertex(p3);
                        data.addVertex(p4);
                        data.addTexCoord(t00);
                        data.addTexCoord(t11);
                        data.addTexCoord(t10);
                    }

                }
            }
        }
    }
}
